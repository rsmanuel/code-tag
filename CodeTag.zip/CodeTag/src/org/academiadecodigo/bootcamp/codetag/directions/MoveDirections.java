package org.academiadecodigo.bootcamp.codetag.directions;

public enum MoveDirections {
    LEFT,
    RIGHT,
    UP,
    DOWN,
}
