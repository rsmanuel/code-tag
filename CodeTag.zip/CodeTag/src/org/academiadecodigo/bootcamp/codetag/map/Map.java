package org.academiadecodigo.bootcamp.codetag.map;
import org.academiadecodigo.simplegraphics.pictures.Picture;

public interface Map {
    Picture getBackground();
}

