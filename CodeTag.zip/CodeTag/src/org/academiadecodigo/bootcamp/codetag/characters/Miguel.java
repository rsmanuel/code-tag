package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;

public class Miguel extends AcademiaDeCodigo{
    public Miguel(Map level) throws InterruptedException {
        super("pics/characters/miguelLeft.png", "pics/characters/miguelRight.png", 20, level);
    }
}
