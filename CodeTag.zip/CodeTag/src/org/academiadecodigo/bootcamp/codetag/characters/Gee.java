package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;

public class Gee extends AcademiaDeCodigo{
    public Gee(Map level) throws InterruptedException {
        super("pics/characters/geeLeft.png", "pics/characters/geeRight.png", 20, level);
    }
}
