package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;


public class Mike42 extends QuarentaEDois {
    public Mike42(Map level) {
        super("pics/characters/mike42left.png", "pics/characters/mike42Right.png", 10, level);
    }
}


