package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;


public class Rodrigo42 extends QuarentaEDois {
    public Rodrigo42(Map level) {
        super("pics/characters/rodrigo42left.png", "pics/characters/rodrigo42Right.png", 10, level);
    }
}

