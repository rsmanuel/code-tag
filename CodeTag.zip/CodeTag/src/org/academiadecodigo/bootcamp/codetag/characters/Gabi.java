package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;

public class Gabi extends AcademiaDeCodigo {
    public Gabi (Map level) throws InterruptedException {
        super("pics/characters/gabiLeft.png", "pics/characters/gabiRight.png", 20, level);
    }
}
