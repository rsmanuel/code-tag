package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;

public class Teresa42 extends QuarentaEDois {
    public Teresa42(Map level) {
        super("pics/characters/teresa42left.png", "pics/characters/teresa42Right.png",10, level);
    }
}

