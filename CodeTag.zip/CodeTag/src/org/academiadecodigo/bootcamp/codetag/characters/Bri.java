package org.academiadecodigo.bootcamp.codetag.characters;

import org.academiadecodigo.bootcamp.codetag.map.Map;

public class Bri extends AcademiaDeCodigo {
    public Bri (Map level) throws InterruptedException {
        super("pics/characters/briLeft.png", "pics/characters/briRight.png", 20, level);
    }
}
